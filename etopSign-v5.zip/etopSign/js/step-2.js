let player = document.getElementById("recepient-list-for-drag");
new Sortable(player, {
    handle: '.handle',
    animation: 200
});


function verifyRecepients() {
    $('.invalid-feedback').hide();

    let recepientsArr = $('.recepient').toArray();
    let namesArr = $('[name="name"]').toArray();
    let emailsArr = $('[name="email"]').toArray();
    let signTypesArr = $('[name="signType"]').toArray();
    let isAccessCodesArr = $('[name="isAccessCode"]').toArray();
    let accessCodesArr = $('[name="accessCode"]').toArray();

    let totalRecepients = recepientsArr.length;

    const mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (totalRecepients == 0) {
        let modalTitle = `Error`
        let modalBody = `Add atleast one recepient to prepare document`
        loadModal(modalTitle, modalBody, true, '');
        return;
    }

    let isError = false;

    for (let i = 0; i < totalRecepients; i++) {

        let recepient = {
            name: $(namesArr[i]).val(),
            email: $(emailsArr[i]).val(),
            signType: $(signTypesArr[i]).val(),
            isAccessCode: $(isAccessCodesArr[i]).val() == 'true' ? true : false,
            accessCode: $(accessCodesArr[i]).val(),
        };

        if (recepient.name.trim() == '') {
            $(namesArr[i]).next().show();
            isError = true;
        }

        if (!recepient.email.match(mailformat)) {
            $(emailsArr[i]).next().show();
            isError = true;
        }

        if (recepient.isAccessCode) {
            if (recepient.accessCode.trim().length != 6) {
                $(accessCodesArr[i]).next().show();
                isError = true;
            }
        }
        recepients.push(recepient);
    }
    if (!isError) {
        gotoStep3();
    }

}

function checkIsAccessCode(trgt) {
    if ($(trgt).val() == 'true') {
        $(trgt).parent().parent().find('.access-code-box').show();
    } else {
        $(trgt).parent().parent().find('.access-code-box').hide();
    }
}

function checkSignType(trgt) {

    if ($(trgt).val() == 'cc') {
        $(trgt).parent().parent().parent().find('.access-code-box').hide();
        $(trgt).parent().parent().parent().find('.isAccess-code-box').hide();
    } else {
        $(trgt).parent().parent().parent().find('.isAccess-code-box').show();
        if ($($(trgt).parent().parent().parent().find('[name="isAccessCode"]')).val() == 'true') {
            $(trgt).parent().parent().parent().find('.access-code-box').show();
        }
    }
}

function changeIsOrdreStatus() {
    if ($('#isOrder').prop('checked')) {
        $('.handler').show();
        isOrder = true;
    } else {
        $('.handler').hide();
        isOrder = false;
    }
}


function addRecepient() {
    let recepHtml = `
    <div class="recepient border p-3 my-3" style="border-radius:10px">
        <div class="d-flex">
            <div class="handler">
                <div class="handle d-inline-block" style="cursor:grabbing;"> <i
                        class="fas fa-bars"></i>
                </div>
            </div>
            <button class="btn btn-danger px-2 py-0 ml-auto" onclick="removeRecepient(this)"> <i
                    class="fas fa-times"></i> </button>
        </div>
        <div class="row m-0">
            <div class="form-group col-md-4">
                <label>Name</label>
                <input type="text" name="name" class="form-control ">
                <div class="invalid-feedback">Inavalid name</div>
            </div>
            <div class="form-group col-md-4">
                <label>Signin Type</label>
                <select name="signType" id="" class="form-control" onchange="checkSignType(this)">
                    <option value="sign">Need to Sign</option>
                    <option value="cc">Receives CC</option>
                </select>
            </div>
        </div>
        <div class="row m-0">
            <div class="form-group col-md-4">
                <label>Email</label>
                <input type="email" name="email" class="form-control">
                <div class="invalid-feedback">Inavalid Email</div>
            </div>
            <div class="form-group col-md-4 isAccess-code-box">
                <label>Access Code</label>
                <select name="isAccessCode" id="" class="form-control"
                    onchange="checkIsAccessCode(this)">
                    <option value="false">None</option>
                    <option value="true">Access Code</option>
                </select>
            </div>
            <div class="form-group col-md-4 access-code-box">
                <label>Code</label>
                <input type="number" name="accessCode" class="form-control ">
                <div class="invalid-feedback">Enter six digit access code</div>
            </div>
        </div>
    </div>
    `;

    $('.recepients').append(recepHtml);
}

function removeRecepient(trgt) {
    $(trgt).parent().parent().remove();
}