function uploadDocument() {
    const ref = firebase.storage().ref();
    const file = document.querySelector("#photo").files[0];
    const name = +new Date() + "-" + file.name;
    const metadata = {
        contentType: file.type,
    };

    $('.add-file').hide();
    $('.loader').show();

    const task = ref.child(name).put(file, metadata);
    task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then(url => {
            previewImage(url);
            fileURL = url;
        })
        .catch(console.error);
}

async function previewImage(url) {

    var pdfjsLib = window['pdfjs-dist/build/pdf'];

    pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

    var loadingTask = pdfjsLib.getDocument(url);
    loadingTask.promise.then(async function (pdf) {

        var pageNumber = 1;

        await pdf.getPage(pageNumber).then(function (page) {

            var canvas = document.getElementById('preview-canvas');
            var context = canvas.getContext('2d');
            var scale = 0.5;
            var viewport = page.getViewport({
                scale: scale
            });

            var renderContext = {
                canvasContext: context,
                viewport: viewport
            };
            var renderTask = page.render(renderContext);
            renderTask.promise.then(function () {
                $('.loader').hide();
                $('#preview-canvas').show();
                $('.step1-btn').show();
            });
        });

    },
        function (reason) {
            console.error(reason);
        });
}
