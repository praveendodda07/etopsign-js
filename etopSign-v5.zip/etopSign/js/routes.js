function gotoStep2() {
    $('.step1').hide();
    $('.step2').show();
    $('.step4').hide();
    $('.step3').hide();
}

gotoStep2();
// gotoStep3();

function gotoStep3() {
    $('.step1').hide();
    $('.step2').hide();
    $('.step4').hide();
    $('.step3').show();

    $('.panel').addClass('w-100');
    $('.nav-bar').hide();

    setUpStep3();
}

function setUpStep3() {
    let recepOptions = '';
    for (let i = 0; i < recepients.length; i++) {
        if (recepients[i].signType != 'cc') {
            recepOptions += `<option value="${i}">${recepients[i].name}</option>`;
        }
    }
    $('[name="recepients-names"]').html(recepOptions);

    currentRecepient = $('[name="recepients-names"]').val();

    pdf2img(fileURL);
}

function gotoStep4() {
    $('.step1').hide();
    $('.step2').hide();
    $('.step3').hide();
    $('.step4').show();
}

function gotoStep5() {
    $('.step1').hide();
    $('.step2').hide();
    $('.step3').hide();
    $('.step4').hide();
    $('.step5').show();
}