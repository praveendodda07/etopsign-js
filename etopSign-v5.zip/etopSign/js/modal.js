function loadModal(modalTitle, modalBody, isDismiss, funBtn) {

    $('#modalTitle').html(modalTitle);
    $('#modalBody').html(modalBody);
    isDismiss ? $('#isDismiss').show() : $('#isDismiss').hide();
    $('#funBtn').html(funBtn);

    $('#modalWidget').modal('show');
}