function loadedSpinner(targetId, text, isDisabled) {
    $('#' + targetId).html(`<span class="spinner-border spinner-border-sm mt-1" role="status" aria-hidden="true"></span> ` + text);
    $('#' + targetId).attr('disabled', isDisabled);
}