async function pdf2img(url) {

    url = './test.pdf';

    var pdfjsLib = window['pdfjs-dist/build/pdf'];

    pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

    var loadingTask = pdfjsLib.getDocument(url);
    loadingTask.promise.then(async function (pdf) {


        var pageNumber = 1;
        var numPages = 0;

        await pdfjsLib.getDocument(url).promise.then(
            function (doc) {
                numPages = doc.numPages;
            });


        for (let i = 0; i < numPages; i++) {

            pageNumber = i + 1;

            await pdf.getPage(pageNumber).then(function (page) {

                var scale = 1.0;
                var viewport = page.getViewport({
                    scale: scale
                });

                var canvasElem = `
                <div class="document" ondrop="drop(event)" ondragover="allowDrop(event)" style="width: ${viewport.width}px; height:${viewport.height}px">
                    <canvas class="canvas${pageNumber}" id="canvas${pageNumber}" width="${viewport.width}" height="${viewport.height}"></canvas> 
                </div>
                `

                $('.document-body').append(canvasElem);

                var canvas = document.getElementById(`canvas${pageNumber}`);
                var context = canvas.getContext('2d');

                var renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                var renderTask = page.render(renderContext);
                renderTask.promise.then(function () {
                });
            });
        }


        // let test_doc = $('.document').toArray()[0];

        // let fileElem = `<div class="resizable text-widget widget">hi</div>`;

        // $(test_doc).append(fileElem);
        // console.log(test_doc);
    },
        function (reason) {
            console.error(reason);
        });
}

async function parsePdf(url, recepData) {

    var pdfjsLib = window['pdfjs-dist/build/pdf'];

    pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

    var loadingTask = pdfjsLib.getDocument(url);
    loadingTask.promise.then(async function (pdf) {


        var pageNumber = 1;
        var numPages = 0;

        await pdfjsLib.getDocument(url).promise.then(
            function (doc) {
                numPages = doc.numPages;
            });


        for (let i = 0; i < numPages; i++) {

            pageNumber = i + 1;

            await pdf.getPage(pageNumber).then(function (page) {

                var scale = 1.0;
                var viewport = page.getViewport({
                    scale: scale
                });

                var canvasElem = `
                <div class="document" ondrop="drop(event)" ondragover="allowDrop(event)" style="width: ${viewport.width}px; height:${viewport.height}px">
                    <canvas class="canvas${pageNumber}" id="canvas${pageNumber}" width="${viewport.width}" height="${viewport.height}"></canvas> 
                </div>
                `

                $('.document-body').append(canvasElem);

                var canvas = document.getElementById(`canvas${pageNumber}`);
                var context = canvas.getContext('2d');

                var renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                var renderTask = page.render(renderContext);
                renderTask.promise.then(function () {
                });
            });
        }


        generateDOM(recepData);

        // let test_doc = $('.document').toArray()[0];

        // let fileElem = `<div class="resizable text-widget widget">hi</div>`;

        // $(test_doc).append(fileElem);
        // console.log(test_doc);
    },
        function (reason) {
            console.error(reason);
        });
}



updateResizes();
function updateResizes() {
    $('.resizable').draggable({
        containment: "parent"
    });
    $('.resizable').resizable({
        handles: "n, e, s, w, se, ne, sw, nw",
        minHeight: 23,
        minWidth: 50,
    });
}

let targetElement = '';

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
    ev.dataTransfer.effectAllowed = "copy";
}

function allowDrop(ev) {
    ev.preventDefault();
}

function drop(ev) {
    ev.preventDefault();
    var x = ev.clientX - $(ev.target).position().left - 65;
    var y = ev.clientY - $(ev.target).position().top - 25;

    var data = ev.dataTransfer.getData("text");

    let widget = '';

    const recep_of_index = currentRecepient;

    switch (data) {
        case 'text':
            widget = `<div class="resizable text-widget widget  widget-${currentRecepient}" style="top:${y}px;left:${x}px" data-widget="TEXT-TOOL" data-recpient="${recep_of_index}" data-isrequired="true" data-isdisabled="false" data-type="text"></div>`;
            break;

        case 'name':
            widget = `<div class="resizable name-widget widget  widget-${currentRecepient}" style="top:${y}px;left:${x}px" data-widget="NAME-TOOL" data-recpient="${recep_of_index}">${recepients[recep_of_index].name}</div>`;
            break;

        case 'email':
            widget = `<div class="resizable email-widget widget  widget-${currentRecepient}" style="top:${y}px;left:${x}px" data-widget="EMAIL-TOOL" data-recpient="${recep_of_index}">${recepients[recep_of_index].email}</div>`;
            break;

        case 'dateTime':
            widget = `<div class="resizable dateTime-widget widget  widget-${currentRecepient}" style="top:${y}px;left:${x}px" data-widget="DATETIME-TOOL" data-recpient="${recep_of_index}">Date and Time</div>`;
            break;

        case 'signature':
            widget = `
            <div class="resizable sis-wig signature-widget widget  widget-${currentRecepient}" style="top:${y}px;left:${x}px" data-widget="SIGNATURE-TOOL" data-recpient="${recep_of_index}">
                <div class="sis-wig" style="pointer-events: none;"> Sign </div>
                <div class="sis-wig" style="pointer-events: none;"> <i class="sis-wig fas fa-signature"></i> </div>
            </div>`;
            break;

        case 'initial':
            widget = `
            <div class="resizable sis-wig initial-widget widget  widget-${currentRecepient}" style="top:${y}px;left:${x}px" data-widget="INITIAL-TOOL" data-recpient="${recep_of_index}">
                <div class="sis-wig" style="pointer-events: none;"> Initial </div>
                <div class="sis-wig" style="pointer-events: none;"> <i class="sis-wig fab fa-draft2digital"></i> </div>
            </div>`;
            break;

        case 'stamp':
            widget = `
            <div class="resizable widget sis-wig stamp-widget widget-${currentRecepient}"  style="top:${y}px;left:${x}px" data-widget="STAMP-TOOL" data-recpient="${recep_of_index}">
                <div class="sis-wig" style="pointer-events: none;"> Stamp </div>
                <div class="sis-wig" style="pointer-events: none;"> <i class="sis-wig fas fa-stamp"></i> </div>
            </div>`;
            break;
    }

    $(ev.target).append(widget);
    updateResizes();

    // let div = ``;

}



function changeText() {
    targetElement.html($('.input-text').val());

    updateResizes();
}
function changeFontSize() {
    targetElement.css('font-size', $('.font-size').val());
}
function changeFontFamily() {
    targetElement.css('font-family', $('.font-style').val());
}

function changeIsRequire() {
    targetElement.data('isrequired', $('.isRequireCheck').prop('checked'));
}
function changeIsDisable() {
    targetElement.data('isdisabled', $('.isDisableCheck').prop('checked'));
}
function changeInputType() {
    targetElement.data('type', $('.input-type').val());
}

function removeWidget() {
    targetElement.remove();
    $('.config').hide();

}

function monitorClick(ev) {
    if ($(ev.target).hasClass('text-widget')) {
        targetElement = $(ev.target);

        $('.font-style').val(targetElement.css('font-family'));
        $('.font-size').val(targetElement.css('font-size'));
        $('.input-text').val(targetElement.text());
        $('.isRequireCheck').prop('checked', targetElement.data("isrequired"));
        $('.isDisableCheck').prop('checked', targetElement.data("isdisabled"));
        $('.input-type').val(targetElement.data("type"));

        $('.text-config-only').show();
        $('.t-e-n').show();
        $('.config').show();
    }
    else if ($(ev.target).hasClass('email-widget') || $(ev.target).hasClass('name-widget') || $(ev.target).hasClass('dateTime-widget')) {
        targetElement = $(ev.target);

        $('.font-style').val(targetElement.css('font-family'));
        $('.font-size').val(targetElement.css('font-size'));

        $('.text-config-only').hide();
        $('.t-e-n').show();
        $('.config').show();
    }
    else if ($(ev.target).hasClass('sis-wig')) {
        targetElement = $(ev.target);

        $('.t-e-n').hide();
        $('.text-config-only').hide();
        $('.config').show();
    }

}

function showThisrecp(clickedRecp) {

    currentRecepient = clickedRecp;

    $('.widget').hide();
    $('.widget-' + clickedRecp).show();
    $('.config').hide();
}


$('body').on('click', monitorClick);
