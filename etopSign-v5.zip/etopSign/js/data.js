// let fileURL = 'https://firebasestorage.googleapis.com/v0/b/etop-sign-655ae.appspot.com/o/1617770592533-1608117888059.pdf?alt=media&token=c0bb7bde-476a-4dea-8351-c53063921fb4';

let fileURL = './test.pdf';
// let fileURL = '';

let isOrder = false;


let recepients = [
];

recepients = [];


let currentRecepient = '0';